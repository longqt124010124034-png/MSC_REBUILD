"use client"

import ContactForm from "../ContactForm"

const ContactSection = () => {
  return <ContactForm />
}

export default ContactSection
